Attention aux Flap et au Gold (Les rats volants). Puisque qu'ils
flottent et n'ont donc pas de point d'attache au sol
Le point de pivot doit se placer � leur centre et le 
mouvement de haut en bas fait depuis Unreal.

Points de pivots :

Speed Neutral Front - Top Central
Speed Neutral Side  - Central Central
Tank Neutral Front  - Central Central
Tank Neutral Side   - Bottom Central
Grunt Front         - Central Central